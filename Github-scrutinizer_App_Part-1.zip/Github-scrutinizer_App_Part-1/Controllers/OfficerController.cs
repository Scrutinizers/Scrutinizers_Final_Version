﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ScrutinizerApp.Models;
using System.Web.Script.Serialization;
namespace ScrutinizerApp.Controllers
{
    public class OfficerController : Controller
    {
        //
        // GET: /Officer/
        string cs = ConfigurationManager.ConnectionStrings["ScrutinizerConnection"].ConnectionString;

        Test_ProjectEntities obj = new Test_ProjectEntities();
        JavaScriptSerializer js = new JavaScriptSerializer();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Case_Details()
        {
            return View();
        }
        public ActionResult Criminal_Details()
        {
            return View();
        }
        public ActionResult Arrest_Details()
        {
            return View();
        }
        public ActionResult Booking_Details()
        {
            return View();
        }

        public int CaseDetailsRecieve(string name, string date, string evidence, string witness, string description)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertCaseDetails]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@date", date);
            cmd.Parameters.AddWithValue("@evidence", evidence);
            cmd.Parameters.AddWithValue("@witness", witness);
            cmd.Parameters.AddWithValue("@description", description);
            
            int result = cmd.ExecuteNonQuery();
            return result;
        }

        public int CriminalDetailsRecieve(string name, string age, string gender, string height, string weight, string identity, string native, string address)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertCriminalDetails]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@age", age);
            cmd.Parameters.AddWithValue("@gender", gender);
            cmd.Parameters.AddWithValue("@height", height);
            cmd.Parameters.AddWithValue("@weight", weight);
            cmd.Parameters.AddWithValue("@identity", identity);
            cmd.Parameters.AddWithValue("@native", native);
            cmd.Parameters.AddWithValue("@address", address);
            

            int result = cmd.ExecuteNonQuery();
            return result;
        }

        public int ArrestDetailsRecieve(string place, string time, string date)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertArrestDetails]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@place", place);
            cmd.Parameters.AddWithValue("@time", time);
            cmd.Parameters.AddWithValue("@date", date);
            

            int result = cmd.ExecuteNonQuery();
            return result;
        }

        public int BookDetailRecieve(string book)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertBooking]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@book", book);
            


            int result = cmd.ExecuteNonQuery();
            return result;
        }


        public string GetOfficerDetails()
        {
            string officername = Session["OffierName"].ToString();
            object obj1 = obj.USP_GetOfficerDetails(officername);
           string result=js.Serialize(obj1);
           return result;
        }
        public string GetComplaintDetails()
        {
            string officername = Session["OffierName"].ToString();
            object obj1 = obj.USP_GetOfficercomplaintDetails(officername);
            string result = js.Serialize(obj1);
            return result;
        }
        //GetComplaintType
        public string GetComplaintType()
        {
            object obj1 = obj.USP_GetComplientDetails();
            string result = js.Serialize(obj1);
            return result;
        }
    }
}
