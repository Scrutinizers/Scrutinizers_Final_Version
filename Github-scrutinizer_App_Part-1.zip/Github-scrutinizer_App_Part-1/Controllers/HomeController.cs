﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ScrutinizerApp.Models;
using System.Web.Script.Serialization;
namespace ScrutinizerApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        string cs = ConfigurationManager.ConnectionStrings["ScrutinizerConnection"].ConnectionString;
        Test_ProjectEntities obj = new Test_ProjectEntities();
        JavaScriptSerializer js = new JavaScriptSerializer();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Public_SignUp()
        {
            return View();
        }
        public ActionResult Appointing_Officer()
        {
            return View();
        }
        public ActionResult User_Registration()
        {
            return View();
        }
        public ActionResult Officer_Login()
        {
            return View();
        }
        public ActionResult Admin_Login()
        {
            return View();
        }
        public ActionResult Userdash_Details()
        {
            ViewBag.Username = Session["UserName"].ToString();
            return View();
        }
        public ActionResult Test()
        {
            return View();
        }
        public int Registration(string name, string password, string city, string address, string complainttype, string complaint)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertUserDetails]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@complainttype", complainttype);
            cmd.Parameters.AddWithValue("@complaint", complaint);
            int result = cmd.ExecuteNonQuery();
            return result;
        }
        public int Signin(string name, string password)
        {
            int flag = 0, opt = 0;
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_checkpublicuser]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userName", name);
            cmd.Parameters.AddWithValue("@password", password);
            int result = (int)cmd.ExecuteScalar();
            if (result > 0)
            {
                Session["UserName"] = name;
                
                flag = 1;
            }
            if (flag > 0)
            {
                opt = result;
            }
           
            return opt;
        }
        public int Officer_Registration(string name, string password, string stationno, string stationaddress, string designation, string gender, string age, string complaintType, string complaint)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_insertOfficerDetails]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@stationNo", stationno);
            cmd.Parameters.AddWithValue("@stationAddress", stationaddress);
            cmd.Parameters.AddWithValue("@designation", designation);
            cmd.Parameters.AddWithValue("@gender", gender);
            cmd.Parameters.AddWithValue("@age", int.Parse(age));
            cmd.Parameters.AddWithValue("@complaintType", complaintType);
            cmd.Parameters.AddWithValue("@complaint", complaint);
            int result = cmd.ExecuteNonQuery();
            return result;
        }
        public int OfficerSignin(string name, string password)
        {
            int flag = 0,opt=0;
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_checkofficeruser]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@officerName", name);
            cmd.Parameters.AddWithValue("@password", password);
            int result = (int)cmd.ExecuteScalar();
           if(result>0)
           {
               Session["OffierName"] = name;
               flag = 1;
           }
           if (flag > 0)
           {
               opt = result;
           }
           return opt;
        }

        public string GetUserDetails()
        {
            string username = Session["UserName"].ToString();
            object obj1 = obj.USP_GetUserDetails(username);
            string result = js.Serialize(obj1);
            return result;
        }


        public string GetCOMPLAINTBookingDetails()
        {
            object obj1 = obj.USP_GetBookingDetailsNew();
            string result = js.Serialize(obj1);
            return result;
        }

    }
}
