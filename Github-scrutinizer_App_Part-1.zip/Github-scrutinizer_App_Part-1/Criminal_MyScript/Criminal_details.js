﻿$(document).ready(function () {
    $("#submit").click(function () {
        var criminal_nm = $("#criminal_name").val();
        var Birth_Dt = $("#Birthdate").val();
        var gender = $("#gender").val();
        var height = $("#height").val();
        var weight = $("#weight").val();
        var identity = $("#identity").val();
        var native = $("#native").val();
        var address = $("#address").val();

        //alert(criminal_nm + " " + Birth_Dt + " " + gender + " " + height + " " + weight + " " + identity + " " + native + " " + address);

        $.ajax({
            url: '/CriminalDetails/Criminal_View',
            async: false,
            type: 'GET',
            data: { "criminalName": criminal_nm, "birthdate": Birth_Dt, "gender": gender, "height": height, "weight": weight ,"identity" :identity , "native" :native ,"address" : address },
            dataType: 'json',
            ContentType: 'application/json;charset=utf-8',
            Success: function (data) {
                alert("Registered successfully");
            },

            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });
    });
});