﻿$(document).ready(function () {
    $("#btn_firsubmit").click(function () {
        var firbook = $("#book").val();

        
        if (firbook == 'Yes')
        {
            var book = 'Case Accepted and Investigation is Done!!!-Contact Scrutinizers for further Updates';
        }
        else
        {
            var book = 'Case Accepted and Investigation is Under Process!!!-Contact Scrutinizers for further Updates ';
        }

        // alert(name)

        $.ajax({
            url: '/Officer/BookDetailRecieve',
            async: false,
            type: 'GET',
            data: { "book": book},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("FIR Status Accepted!!!");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });


    });
    $("#btn_booklogout").click(function () {

        window.location.href = "/Home/Index";

    });

});