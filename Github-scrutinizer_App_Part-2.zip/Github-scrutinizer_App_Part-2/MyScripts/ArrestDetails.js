﻿$(document).ready(function () {
    $("#btn_arrestsubmit").click(function () {
        var place = $("#place").val();
        var time = $("#time").val();
        var date = $("#date").val();

       // alert(place + " " + time + " " + date)

        $.ajax({
            url: '/Officer/ArrestDetailsRecieve',
            async: false,
            type: 'GET',
            data: { "place": place, "time": time, "date": date},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Details Recieved!!!");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });
    });

});