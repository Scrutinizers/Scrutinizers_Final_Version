﻿$(document).ready(function () {
    $("#btn_loginOfficer").click(function () {
        var name = $("#olname").val();
        var password = $("#olpassword").val();


        //alert(name+" "+password)
        $.ajax({
            url: '/Home/OfficerSignin',
            async: false,
            type: 'GET',
            data: { "name": name, "password": password },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                if (data > 0)
                    window.location.href = "/Officer/Index";
                else
                    $("#lblofficererror").text("Invalid OfficerName or Password");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });


    });
    $("#btn_offhome").click(function () {

        window.location.href = "/Home/Index";

    });

});