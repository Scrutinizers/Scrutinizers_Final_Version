﻿$(document).ready(function () {
    $("#btn_adminlogin").click(function () {
        var name = $("#aname").val();
        var password = $("#apassword").val();

        //alert(name + " " + password);

       if(name=="Admin"&&password=="Admin@123")
       {
            window.location.href = "/Home/Appointing_Officer";
       }
        else
       {
           $("#invalid").text("INVALID ADMIN NAME OR PASSWORD");
       }

    });
    $("#btn_home").click(function () {

        window.location.href = "/Home/Index";

    });

});