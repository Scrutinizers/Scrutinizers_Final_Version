﻿$(document).ready(function () {

    $("#tblUser").dataTable({

        "ajax": {
            "url": "/Home/GetUserDetails",
            "dataSrc": ""
        },

        "columns": [
            { "data": "userName" },
            { "data": "city" },
            { "data": "address" },
            { "data": "complaintType" },
            { "data": "complaint" }
        ]

    });

    GetBooking();

    function GetBooking() {
        
        $("#tblCOMPLAINT").dataTable({

            "ajax": {
                "url": "/Home/GetCOMPLAINTBookingDetails",
                "dataSrc": ""
            },

            "columns": [
                { "data": "bookingStatus" }

            ]

        });

    }
    $("#btn_userlogout").click(function () {
       
            window.location.href = "/Home/Public_SignUp";

        });


    });