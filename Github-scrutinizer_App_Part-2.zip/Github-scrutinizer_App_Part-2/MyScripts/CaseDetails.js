﻿$(document).ready(function () {
    $("#btn_casesubmit").click(function () {
        var name = $("#name").val();
        var date = $("#date").val();
        var evidence = $("#evidence").val();
        var witness = $("#witness").val();
        var description = $("#description").val();
        

        //alert(name+" "+date+" "+evidence+" "+witness+" "+description)
        $.ajax({
            url: '/Officer/CaseDetailsRecieve',
            async: false,
            type: 'GET',
            data: { "name": name, "date": date, "evidence": evidence, "witness": witness, "description": description },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Details Recieved!!!");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });

    });

});