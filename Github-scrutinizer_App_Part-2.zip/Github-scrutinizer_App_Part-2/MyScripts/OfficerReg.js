﻿$(document).ready(function () {

    GetComplaintType();
    GetComplaint();

    function GetComplaintType() {
        var ComplaintType = $("#ComplaintType");
        $.ajax({
            url: "/Officer/GetComplaintType",
            type: "GET",
            async: false,
            dataType: "json",
            contentType: "application/json",
            /* success: function (res) {           
                 var res1 = JSON.stringify(res);;
                 alert(res1);
                 $.each(res1.d, function (data, value) {
                     $("#ComplaintType").append($("<option></option>").val(value.complaintType).html(value.complaintType));
                 })
             }*/
            success: function (response) {
                ComplaintType.empty().append('<option selected="selected" value="0">Please Select Complaint Type</option>');

                $.each(response, function () {
                    ComplaintType.append($("<option></option>").val(this['complaintType']).html(this['complaintType']));

                });
            }
        });
    }

    function GetComplaint() {
        var Complaint = $("#Complaint");
        $.ajax({
            url: "/Officer/GetComplaintType",
            type: "GET",
            async: false,
            dataType: "json",
            contentType: "application/json",
            /* success: function (res) {           
                 var res1 = JSON.stringify(res);;
                 alert(res1);
                 $.each(res1.d, function (data, value) {
                     $("#ComplaintType").append($("<option></option>").val(value.complaintType).html(value.complaintType));
                 })
             }*/
            success: function (response) {
                Complaint.empty().append('<option selected="selected" value="0">Please Select Complaint</option>');

                $.each(response, function () {
                    Complaint.append($("<option></option>").val(this['complaint']).html(this['complaint']));

                });
            }
        });
    }

    $("#btn_appoint").click(function () {
        var name = $("#oname").val();
        var password = $("#opassword").val();
        var stationno = $("#ostationno").val();
        var stationaddress = $("#ostationaddress").val();
        var designation = $("#odesignation").val();
        var gender = $("#ogender").val();
        var age = $("#oage").val();
        var complaintType = $("#ComplaintType").val();
        var complaint = $("#Complaint").val();


        // alert(name + " " + password + " " + stationno + " " + stationaddress + " " + designation + " " + gender + " " + age)
        $.ajax({
            url: '/Home/Officer_Registration',
            async: false,
            type: 'GET',
            data: { "name": name, "password": password, "stationno": stationno, "stationaddress": stationaddress, "designation": designation, "gender": gender, "age": age, "complaintType": complaintType, "complaint": complaint },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration Done");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });


    });
    $("#btn_Adminlogout").click(function () {
        window.location.href = "/Home/Admin_Login";

    });

});