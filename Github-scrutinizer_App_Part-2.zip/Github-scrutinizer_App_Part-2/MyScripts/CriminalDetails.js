﻿$(document).ready(function () {
    $("#btn_criminaldetails").click(function () {
        var name = $("#criminal_name").val();
        var age = $("#criminal_age").val();
        var gender = $("#gender").val();
        var height = $("#height").val();
        var weight = $("#weight").val();
        var identity = $("#identity").val();
        var native = $("#native").val();
        var address = $("#address").val();
        

        //alert(name + " " + age + " " + gender + " " + height + " " + weight + " " + identity + " " + native + " " + address)

        $.ajax({
            url: '/Officer/CriminalDetailsRecieve',
            async: false,
            type: 'GET',
            data: { "name": name, "age": age, "gender": gender, "height": height, "weight": weight, "identity": identity, "native": native, "address": address },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Details Recieved!!!");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });
    });

});