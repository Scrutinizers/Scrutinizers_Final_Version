﻿$(document).ready(function () {
    $("#tblOfficer").dataTable({

        "ajax": {
            "url": "/Officer/GetOfficerDetails",
            "dataSrc": ""
        },

        "columns": [
            { "data": "officerName" },
            { "data": "stationNo" },
            { "data": "stationAddress" },
            { "data": "designation" },
            { "data": "gender" },
            { "data": "age" }
          
        ]

    });

    $("#tblComplient").dataTable({

        "ajax": {
            "url": "/Officer/GetComplaintDetails",
            "dataSrc": ""
        },

        "columns": [
            { "data": "complaintType" },
            { "data": "complaint" }         

        ]

    });
    });

